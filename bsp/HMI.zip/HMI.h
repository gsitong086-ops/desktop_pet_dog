/**
  ******************************************************************************
  * @file    HMI.h
  * @author  SZTU OSHA
  * @brief   语音人机交互模块
  *
  ******************************************************************************
  * @attention
  *
  * 语音人机交互模块连接到UART2
  * 使用普通发送模式
  * 使用串口空闲中断+DMA的接收模式 这样可以实现不定长指令的接收
  *
  * 在语音人机交互模块对应串口的中断处理函数USART2_IRQHandler中，
  * 写清除空闲标志位的代码，如下：
  * if(__HAL_UART_GET_FLAG(&huart2, UART_FLAG_IDLE) != RESET){
  *   __HAL_UART_CLEAR_IDLEFLAG(&huart2);
  *   HMI_RxFlag = 1;
  * }
  *
  ******************************************************************************
  * @CubeMXConfiguration（修改成USART2）
  * - 外设配置：USART2 配置为异步通信模式，开启DMA接收功能
  *             波特率：115200bps，数据位：8位，停止位：1位，校验位：无
  *             使能接收中断（IDLE中断），DMA模式为循环接收
  * - 引脚分配：
  *   - PB10: USART3_RX (蓝牙模块接收引脚，连接STM32的发送端)
  *   - PB11: USART3_TX (蓝牙模块发送引脚，连接STM32的接收端)
  *   - DMA1_Channel3: USART3_RX DMA通道（根据芯片型号确认，此处为示例）
  * - 时钟配置：APB1 外设时钟 @ 36MHz（USART3挂载于APB1总线）
  * 
  * 注意：
  * 1. 需启用UART空闲中断 (IDLE Interrupt) 以检测数据包结束
  * 2. DMA配置为循环模式 (Circular Mode)，缓冲区大小为BLUETOOTH_DMA_LENGTH
  * 3. 接收缓冲区大小需根据最大数据包长度调整，避免溢出
  * 4. 引脚功能需在CubeMX中正确配置为USART3复用功能
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __HMI_H__
#define __HMI_H__

#ifdef __cplusplus
extern "C" {
#endif

/* SZTU OSHA Includes-----------------------------------------------------*/
#include "main.h"
#include "stdio.h"
#include "string.h"


/* SZTU OSHA instructions macro-------------------------------------------*/
#define HMI_UART huart2                         //语音人机交互模块连接的串口
#define HMI_DMA hdma_usart2_rx                 //串口对应的接收DMA
#define HMI_DMA_LENGTH 100                              //接收DMA的大小

#define HMI_TO_STM32_HEADER 0x55                //HMI发送给STM32的包头(可选)


/* SZTU OSHA variables----------------------------------------------------*/
extern volatile uint8_t HMI_RxFlag;

/* SZTU OSHA Prototypes---------------------------------------------------*/
void HMI_Init(void);
HAL_StatusTypeDef HMI_send_hex_values(const uint8_t *data, size_t length);
void HMI_process_information(void);

#ifdef __cplusplus
}
#endif

#endif /* __HMI_H__ */




